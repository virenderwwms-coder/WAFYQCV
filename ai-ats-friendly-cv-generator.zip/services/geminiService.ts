
import { GoogleGenAI, Type } from '@google/genai';
import type { UserInput, CVData, WorkExperienceInput, EducationInput } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const responseSchema = {
  type: Type.OBJECT,
  properties: {
    fullName: { type: Type.STRING },
    contact: {
      type: Type.OBJECT,
      properties: {
        email: { type: Type.STRING },
        phone: { type: Type.STRING },
        linkedin: { type: Type.STRING },
      },
      required: ['email', 'phone', 'linkedin'],
    },
    summary: { type: Type.STRING, description: "A well-written professional summary, 3-4 sentences" },
    experience: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          company: { type: Type.STRING },
          dates: { type: Type.STRING },
          description: { type: Type.ARRAY, items: { type: Type.STRING, description: "bullet point" } },
        },
        required: ['title', 'company', 'dates', 'description'],
      },
    },
    education: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          degree: { type: Type.STRING },
          institution: { type: Type.STRING },
          dates: { type: Type.STRING },
        },
        required: ['degree', 'institution', 'dates'],
      },
    },
    skills: { type: Type.ARRAY, items: { type: Type.STRING } },
  },
  required: ['fullName', 'contact', 'summary', 'experience', 'education', 'skills'],
};

const buildPrompt = (userInput: UserInput): string => {
  const experienceString = userInput.experience.map(exp => 
    `- Job Title: ${exp.title}, Company: ${exp.company}, Dates: ${exp.dates}, Responsibilities: ${exp.description}`
  ).join('\n');

  const educationString = userInput.education.map(edu => 
    `- Degree: ${edu.degree}, Institution: ${edu.institution}, Dates: ${edu.dates}`
  ).join('\n');

  return `
You are an expert career coach and professional CV writer specializing in creating ATS-friendly resumes. Your task is to take the raw information provided by a user and transform it into a polished, professional Curriculum Vitae.

**Formatting Rules (Strict):**
- Use clear and standard headings: "Professional Summary", "Work Experience", "Education", "Skills".
- For each "Work Experience" entry, describe responsibilities and achievements using 2-4 bullet points starting with strong action verbs.
- Do not use any tables, columns, or special characters not suitable for an ATS. Use plain text.
- Use a professional and concise tone.
- Optimize the content with relevant keywords for the target role of "${userInput.targetRole}".
- The entire output MUST be in a structured JSON format matching the provided schema. Do not add any introductory text or markdown formatting around the JSON object.

**User's Raw Information:**
- Full Name: ${userInput.fullName}
- Contact Info: Email: ${userInput.email}, Phone: ${userInput.phone}, LinkedIn: ${userInput.linkedin}
- Target Role: ${userInput.targetRole}
- Professional Summary (raw notes): ${userInput.summary || 'Please write a professional summary based on the experience and skills provided.'}
- Work Experience:
${experienceString}
- Education:
${educationString}
- Skills (comma-separated): ${userInput.skills}

Generate the CV content based on this information.
`;
};

export const generateCvContent = async (userInput: UserInput): Promise<CVData> => {
  try {
    const prompt = buildPrompt(userInput);
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-pro',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: responseSchema,
        temperature: 0.5,
      },
    });

    const text = response.text.trim();
    // The response text is already a JSON string because of responseMimeType
    const cvData: CVData = JSON.parse(text);
    return cvData;
  } catch (error) {
    console.error("Error generating CV content from Gemini:", error);
    throw new Error("Failed to generate CV. The AI service may be experiencing issues.");
  }
};
