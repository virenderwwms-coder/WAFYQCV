
import type { CVData } from '../types';

// The 'docx' library is loaded from a CDN and will be available on the window object.
declare const docx: any;

export const generateDocx = (cvData: CVData) => {
  if (typeof docx === 'undefined') {
    alert('DOCX generation library not loaded. Please try again.');
    return;
  }
  
  const { Packer, Document, Paragraph, TextRun, HeadingLevel, AlignmentType } = docx;

  const doc = new Document({
    sections: [{
      properties: {},
      children: [
        // Full Name
        new Paragraph({
          children: [new TextRun({ text: cvData.fullName, bold: true, size: 48 })],
          alignment: AlignmentType.CENTER,
        }),
        // Contact Info
        new Paragraph({
          children: [
            new TextRun(cvData.contact.email),
            new TextRun(" | ").break(),
            new TextRun(cvData.contact.phone),
            ...(cvData.contact.linkedin ? [new TextRun(" | ").break(), new TextRun(cvData.contact.linkedin)] : []),
          ],
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 },
        }),

        // Professional Summary
        new Paragraph({
          children: [new TextRun({ text: "Professional Summary", bold: true, allCaps: true, size: 24 })],
          heading: HeadingLevel.HEADING_1,
          border: { bottom: { color: "auto", space: 1, value: "single", size: 6 } },
          spacing: { after: 100 },
        }),
        new Paragraph({
          children: [new TextRun(cvData.summary)],
          spacing: { after: 200 },
        }),

        // Work Experience
        new Paragraph({
          children: [new TextRun({ text: "Work Experience", bold: true, allCaps: true, size: 24 })],
          heading: HeadingLevel.HEADING_1,
          border: { bottom: { color: "auto", space: 1, value: "single", size: 6 } },
          spacing: { after: 100 },
        }),
        ...cvData.experience.flatMap(exp => [
          new Paragraph({
            children: [
              new TextRun({ text: exp.title, bold: true }),
              new TextRun(`\t${exp.dates}`).tab(),
            ],
            spacing: { after: 50 },
          }),
          new Paragraph({
            children: [new TextRun({ text: exp.company, italics: true })],
            spacing: { after: 50 },
          }),
          ...exp.description.map(desc => new Paragraph({
            text: desc,
            bullet: { level: 0 },
          })),
          new Paragraph(""), // Spacer
        ]),

        // Education
        new Paragraph({
          children: [new TextRun({ text: "Education", bold: true, allCaps: true, size: 24 })],
          heading: HeadingLevel.HEADING_1,
          border: { bottom: { color: "auto", space: 1, value: "single", size: 6 } },
          spacing: { after: 100 },
        }),
        ...cvData.education.map(edu => new Paragraph({
            children: [
                new TextRun({ text: `${edu.degree}, ${edu.institution}`, bold: true }),
                new TextRun(`\t${edu.dates}`).tab(),
            ],
        })),
        new Paragraph({ spacing: { after: 200 } }),


        // Skills
        new Paragraph({
          children: [new TextRun({ text: "Skills", bold: true, allCaps: true, size: 24 })],
          heading: HeadingLevel.HEADING_1,
          border: { bottom: { color: "auto", space: 1, value: "single", size: 6 } },
          spacing: { after: 100 },
        }),
        new Paragraph({
          children: [new TextRun(cvData.skills.join(', '))],
        }),
      ],
    }],
  });

  Packer.toBlob(doc).then(blob => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'cv.docx';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  });
};
