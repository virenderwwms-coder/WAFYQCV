
import React from 'react';
import type { CVData } from '../types';
import { generateDocx } from '../services/documentService';
import { DocxIcon, PdfIcon, SparklesIcon } from './icons';

interface CVPreviewProps {
  cvData: CVData | null;
  isLoading: boolean;
  error: string | null;
}

export const CVPreview: React.FC<CVPreviewProps> = ({ cvData, isLoading, error }) => {
  const handleDownloadPdf = () => {
    const cvElement = document.getElementById('cv-preview-area');
    if (cvElement && (window as any).html2pdf) {
      const options = {
        margin: [0.5, 0.5, 0.5, 0.5],
        filename: 'cv.pdf',
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, useCORS: true },
        jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
      };
      (window as any).html2pdf().from(cvElement).set(options).save();
    }
  };

  const handleDownloadDocx = () => {
    if (cvData) {
      generateDocx(cvData);
    }
  };
  
  const renderContent = () => {
    if (isLoading) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-center">
          <SparklesIcon className="w-16 h-16 text-indigo-400 animate-pulse" />
          <h3 className="mt-4 text-xl font-semibold text-gray-700 dark:text-gray-300">Crafting your CV...</h3>
          <p className="mt-2 text-gray-500 dark:text-gray-400">The AI is polishing your details into an ATS-friendly format.</p>
        </div>
      );
    }

    if (error) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-center p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 rounded-lg">
          <h3 className="text-xl font-semibold text-red-700 dark:text-red-300">An Error Occurred</h3>
          <p className="mt-2 text-red-600 dark:text-red-400">{error}</p>
          <p className="mt-2 text-sm text-gray-500">Please check your network and try again. If the issue persists, the service may be temporarily unavailable.</p>
        </div>
      );
    }

    if (!cvData) {
      return (
        <div className="flex flex-col items-center justify-center h-full text-center">
            <div className="w-24 h-24 bg-gray-200 dark:bg-gray-700 rounded-lg mb-4 flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-400 dark:text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            </div>
            <h3 className="text-xl font-semibold text-gray-700 dark:text-gray-300">Your Generated CV Will Appear Here</h3>
            <p className="mt-2 text-gray-500 dark:text-gray-400">Fill out the form on the left and click "Generate" to see the magic happen.</p>
        </div>
      );
    }

    return (
      <div id="cv-preview-area" className="p-8 bg-white dark:bg-gray-800 text-black dark:text-white font-serif">
        <header className="text-center mb-6">
          <h1 className="text-4xl font-bold tracking-wider">{cvData.fullName}</h1>
          <div className="flex justify-center space-x-4 mt-2 text-sm">
            <span>{cvData.contact.email}</span>
            <span>|</span>
            <span>{cvData.contact.phone}</span>
            {cvData.contact.linkedin && <><span>|</span><span>{cvData.contact.linkedin}</span></>}
          </div>
        </header>

        <section>
          <h2 className="text-xl font-bold border-b-2 border-black dark:border-white pb-1 mb-2">Professional Summary</h2>
          <p className="text-sm">{cvData.summary}</p>
        </section>

        <section className="mt-4">
          <h2 className="text-xl font-bold border-b-2 border-black dark:border-white pb-1 mb-2">Work Experience</h2>
          {cvData.experience.map((exp, index) => (
            <div key={index} className="mb-3">
              <div className="flex justify-between items-baseline">
                <h3 className="text-lg font-bold">{exp.title}</h3>
                <p className="text-sm font-mono">{exp.dates}</p>
              </div>
              <p className="text-md italic">{exp.company}</p>
              <ul className="list-disc list-inside mt-1 text-sm space-y-1">
                {exp.description.map((item, i) => <li key={i}>{item}</li>)}
              </ul>
            </div>
          ))}
        </section>

        <section className="mt-4">
          <h2 className="text-xl font-bold border-b-2 border-black dark:border-white pb-1 mb-2">Education</h2>
          {cvData.education.map((edu, index) => (
            <div key={index} className="flex justify-between items-baseline mb-1">
              <div>
                <h3 className="text-lg font-bold">{edu.degree}</h3>
                <p className="text-md italic">{edu.institution}</p>
              </div>
              <p className="text-sm font-mono">{edu.dates}</p>
            </div>
          ))}
        </section>

        <section className="mt-4">
          <h2 className="text-xl font-bold border-b-2 border-black dark:border-white pb-1 mb-2">Skills</h2>
          <p className="text-sm">{cvData.skills.join(', ')}</p>
        </section>
      </div>
    );
  };
  
  return (
    <div className="sticky top-8">
        <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border border-gray-200 dark:border-gray-700 min-h-[80vh] flex flex-col">
            {cvData && (
                <div className="flex items-center justify-between mb-4 border-b border-gray-200 dark:border-gray-700 pb-4">
                    <h2 className="text-xl font-bold">Preview</h2>
                    <div className="flex space-x-2">
                        <button onClick={handleDownloadPdf} className="flex items-center space-x-2 bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors text-sm font-medium">
                            <PdfIcon className="w-5 h-5" />
                            <span>PDF</span>
                        </button>
                        <button onClick={handleDownloadDocx} className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors text-sm font-medium">
                            <DocxIcon className="w-5 h-5" />
                            <span>DOCX</span>
                        </button>
                    </div>
                </div>
            )}
            <div className="flex-grow overflow-auto">
                {renderContent()}
            </div>
        </div>
    </div>
  );
};
