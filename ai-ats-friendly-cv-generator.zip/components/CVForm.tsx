
import React, { useState } from 'react';
import type { UserInput, WorkExperienceInput, EducationInput } from '../types';
import { PlusIcon, TrashIcon, SparklesIcon } from './icons';

interface CVFormProps {
  onGenerate: (userInput: UserInput) => void;
  isLoading: boolean;
}

export const CVForm: React.FC<CVFormProps> = ({ onGenerate, isLoading }) => {
  const [userInput, setUserInput] = useState<UserInput>({
    fullName: '',
    email: '',
    phone: '',
    linkedin: '',
    targetRole: '',
    summary: '',
    experience: [{ id: crypto.randomUUID(), title: '', company: '', dates: '', description: '' }],
    education: [{ id: crypto.randomUUID(), degree: '', institution: '', dates: '' }],
    skills: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setUserInput(prev => ({ ...prev, [name]: value }));
  };

  const handleExperienceChange = (id: string, e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setUserInput(prev => ({
      ...prev,
      experience: prev.experience.map(exp => (exp.id === id ? { ...exp, [name]: value } : exp)),
    }));
  };

  const addExperience = () => {
    setUserInput(prev => ({
      ...prev,
      experience: [...prev.experience, { id: crypto.randomUUID(), title: '', company: '', dates: '', description: '' }],
    }));
  };

  const removeExperience = (id: string) => {
    setUserInput(prev => ({
      ...prev,
      experience: prev.experience.filter(exp => exp.id !== id),
    }));
  };

  const handleEducationChange = (id: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setUserInput(prev => ({
      ...prev,
      education: prev.education.map(edu => (edu.id === id ? { ...edu, [name]: value } : edu)),
    }));
  };

  const addEducation = () => {
    setUserInput(prev => ({
      ...prev,
      education: [...prev.education, { id: crypto.randomUUID(), degree: '', institution: '', dates: '' }],
    }));
  };

  const removeEducation = (id: string) => {
    setUserInput(prev => ({
      ...prev,
      education: prev.education.filter(edu => edu.id !== id),
    }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onGenerate(userInput);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      <FormSection title="Personal Information">
        <Input label="Full Name" name="fullName" value={userInput.fullName} onChange={handleInputChange} placeholder="e.g., Jane Doe" required />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input label="Email Address" name="email" type="email" value={userInput.email} onChange={handleInputChange} placeholder="e.g., jane.doe@example.com" required />
          <Input label="Phone Number" name="phone" value={userInput.phone} onChange={handleInputChange} placeholder="e.g., (123) 456-7890" />
        </div>
        <Input label="LinkedIn Profile URL" name="linkedin" value={userInput.linkedin} onChange={handleInputChange} placeholder="e.g., linkedin.com/in/janedoe" />
      </FormSection>

      <FormSection title="Career Objective">
        <Input label="Target Role" name="targetRole" value={userInput.targetRole} onChange={handleInputChange} placeholder="e.g., Senior Frontend Developer" required />
        <TextArea label="Professional Summary" name="summary" value={userInput.summary} onChange={handleInputChange} placeholder="Write a brief summary of your career, skills, and goals. Or let the AI write one for you based on your experience!" rows={4} />
      </FormSection>

      <FormSection title="Work Experience">
        {userInput.experience.map((exp, index) => (
          <div key={exp.id} className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg space-y-4 relative">
            {userInput.experience.length > 1 && (
                <button type="button" onClick={() => removeExperience(exp.id)} className="absolute top-2 right-2 text-gray-400 hover:text-red-500">
                    <TrashIcon className="w-5 h-5" />
                </button>
            )}
            <Input label="Job Title" name="title" value={exp.title} onChange={(e) => handleExperienceChange(exp.id, e)} placeholder="e.g., Software Engineer" required/>
            <Input label="Company" name="company" value={exp.company} onChange={(e) => handleExperienceChange(exp.id, e)} placeholder="e.g., Tech Solutions Inc." required/>
            <Input label="Dates" name="dates" value={exp.dates} onChange={(e) => handleExperienceChange(exp.id, e)} placeholder="e.g., Jan 2020 - Present" />
            <TextArea label="Responsibilities & Achievements" name="description" value={exp.description} onChange={(e) => handleExperienceChange(exp.id, e)} placeholder="Describe your role. Use bullet points for key achievements. The AI will refine this." rows={5} required/>
          </div>
        ))}
        <button type="button" onClick={addExperience} className="flex items-center space-x-2 text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-200 font-medium">
          <PlusIcon className="w-5 h-5" />
          <span>Add Another Experience</span>
        </button>
      </FormSection>

      <FormSection title="Education">
        {userInput.education.map((edu, index) => (
            <div key={edu.id} className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg space-y-4 relative">
                {userInput.education.length > 1 && (
                     <button type="button" onClick={() => removeEducation(edu.id)} className="absolute top-2 right-2 text-gray-400 hover:text-red-500">
                        <TrashIcon className="w-5 h-5" />
                    </button>
                )}
                <Input label="Degree / Certificate" name="degree" value={edu.degree} onChange={(e) => handleEducationChange(edu.id, e)} placeholder="e.g., B.S. in Computer Science" required/>
                <Input label="Institution" name="institution" value={edu.institution} onChange={(e) => handleEducationChange(edu.id, e)} placeholder="e.g., State University" required/>
                <Input label="Dates" name="dates" value={edu.dates} onChange={(e) => handleEducationChange(edu.id, e)} placeholder="e.g., Sep 2016 - May 2020" />
            </div>
        ))}
        <button type="button" onClick={addEducation} className="flex items-center space-x-2 text-indigo-600 dark:text-indigo-400 hover:text-indigo-800 dark:hover:text-indigo-200 font-medium">
          <PlusIcon className="w-5 h-5" />
          <span>Add Another Education</span>
        </button>
      </FormSection>

      <FormSection title="Skills">
        <TextArea label="Skills" name="skills" value={userInput.skills} onChange={handleInputChange} placeholder="List your technical and soft skills, separated by commas. e.g., React, TypeScript, Node.js, Project Management, Agile" rows={3} required/>
      </FormSection>

      <div className="pt-4">
        <button type="submit" disabled={isLoading} className="w-full flex items-center justify-center space-x-3 bg-indigo-600 text-white font-bold py-3 px-6 rounded-lg hover:bg-indigo-700 disabled:bg-indigo-300 disabled:cursor-not-allowed transition-colors duration-300 shadow-lg hover:shadow-indigo-500/50">
          {isLoading ? (
            <>
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              <span>Generating...</span>
            </>
          ) : (
            <>
              <SparklesIcon className="w-6 h-6" />
              <span>Generate ATS-Friendly CV</span>
            </>
          )}
        </button>
      </div>
    </form>
  );
};

const FormSection: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="bg-white dark:bg-gray-800 p-6 rounded-lg shadow-md border border-gray-200 dark:border-gray-700">
        <h2 className="text-xl font-bold mb-6 text-gray-800 dark:text-gray-100 border-b pb-2 border-gray-200 dark:border-gray-600">{title}</h2>
        <div className="space-y-4">{children}</div>
    </div>
);

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
}

const Input: React.FC<InputProps> = ({ label, name, ...props }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{label}</label>
        <input id={name} name={name} {...props} className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 text-gray-900 dark:text-gray-100" />
    </div>
);

interface TextAreaProps extends React.TextareaHTMLAttributes<HTMLTextAreaElement> {
  label: string;
}

const TextArea: React.FC<TextAreaProps> = ({ label, name, ...props }) => (
    <div>
        <label htmlFor={name} className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">{label}</label>
        <textarea id={name} name={name} {...props} className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-md shadow-sm focus:ring-indigo-500 focus:border-indigo-500 text-gray-900 dark:text-gray-100" />
    </div>
);
